package com.example.book_app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class PdfAddActivity extends AppCompatActivity {

    private ActivityPdfAddBinding binding;

    private FirebaseAuth firebaseAuth;
    private ArrayList<ModelCategory>categoryArrayList;

    private Url pdfurl=null;

    private static final int PDF_PICK_CODE=1000;

    private static final String TAG="ADD_PDF_TAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityPdfAddBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        firebaseAuth=FirebaseAuth.getInstance();
        loadPdfCategories();

        binding.backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();

            }
        });
        binding.attachBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pdfPickIntent();

            }
            binding.categoryTv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    categoryPickDialog();
                }




            private void pdfPickIntent() {
                Log.d(TAG,msg:"pdfPickIntent: starting pdf pick intent");
                intent intent=new intent();
                intent.setType("application/pdf");
                intent.setAction(intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent,title:"Select Pdf"),PDF_PICK_CODE);
            }

        @Override
        protected void onActivityResult(int requestcode, int resultcode, @NonNull intent data){
                super.onActivityResult(requestcode,resultcode,data)
        }
        });

    }
}

    private void loadPdfCategories() {
        Log.d(TAG,msg:"pdfPickIntent: starting pdf pick intent");
        categoryArrayList=new ArrayList<>();
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference(path:"Categories");
        ref.child()
    }
    }

    private void categoryPickDialog() {
    }