package com.example.book_app;

import android.widget.Filter;

import java.util.ArrayList;
import java.util.List;

public class FilterCategory extends Filter {
    private ArrayList<ModelCategory> filterList;
    private AdapterCategory adapterCategory;

    public FilterCategory(ArrayList<ModelCategory> filterList, AdapterCategory adapterCategory) {
        this.filterList = filterList;
        this.adapterCategory = adapterCategory;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();

        if (constraint != null && constraint.length() > 0) {
            String filterPattern = constraint.toString().toLowerCase().trim();
            ArrayList<ModelCategory> filteredList = new ArrayList<>();
            for (ModelCategory item : filterList) {
                if (item.getCategory().toLowerCase().contains(filterPattern)) {
                    filteredList.add(item);
                }
            }
            results.count = filteredList.size();
            results.values = filteredList;
        } else {
            results.count = filterList.size();
            results.values = filterList;
        }
        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        adapterCategory.categoryArrayList = (ArrayList<ModelCategory>) results.values;
        adapterCategory.notifyDataSetChanged();
    }
}
