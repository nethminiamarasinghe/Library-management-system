package com.example.project_3;
public class Book_Author {
    private String bookId;
    private String authorName;

    public Book_Author(String bookId, String authorName) {
        this.bookId = bookId;
        this.authorName = authorName;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }
}

