package com.example.project_3;

public class Book {
    private String bookId;
    private String title;
    private String publisherName;

    public Book() {
        // Empty constructor required for SQLite
    }

    public Book(String bookId, String title, String publisherName) {
        this.bookId = bookId;
        this.title = title;
        this.publisherName = publisherName;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublisherName() {
        return publisherName;
    }

    public void setPublisherName(String publisherName) {
        this.publisherName = publisherName;
    }
}
