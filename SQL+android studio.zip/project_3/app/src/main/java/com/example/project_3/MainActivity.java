package com.example.project_3;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Creating instances of classes
        Book book = new Book("1", "Book Title", "Publisher Name");
        Publisher publisher = new Publisher("Publisher Name", "Publisher Address", "Publisher Phone");
        Branch branch = new Branch("1", "Branch Name", "Branch Address");
        Member member = new Member("123", "Member Name", "Member Address", "Member Phone", 0.0);
        Book_Author bookAuthor = new Book_Author("1", "Author Name");
        Book_Copy bookCopy = new Book_Copy("1", "1", "Access No");
        Date date = new Date();
        Book_Loan bookLoan = new Book_Loan("Access No", "Branch Id", "Card No");

        // Printing out information for testing
        System.out.println("Book: " + book.toString());
        System.out.println("Publisher: " + publisher.toString());
        System.out.println("Branch: " + branch.toString());
        System.out.println("Member: " + member.toString());
        System.out.println("Book Author: " + bookAuthor.toString());
        System.out.println("Book Copy: " + bookCopy.toString());
        System.out.println("Book Loan: " + bookLoan.toString());
    }
}

