package com.example.project_3;

public class Book_Loan {
    private String accessNo;
    private String branchId;
    private String cardNo;


    public Book_Loan(String accessNo, String branchId, String cardNo) {
        this.accessNo = accessNo;
        this.branchId = branchId;
        this.cardNo = cardNo;

    }

    // Getters and setters for all attributes

    public String getAccessNo() {
        return accessNo;
    }

    public void setAccessNo(String accessNo) {
        this.accessNo = accessNo;
    }

    // Implement getters and setters for other attributes

    // Additional methods as needed

    @Override
    public String toString() {
        return "Book_Loan{" +
                "accessNo='" + accessNo + '\'' +
                ", branchId='" + branchId + '\'' +
                ", cardNo='" + cardNo + '\'' +
                '}';
    }
}

