package com.example.project_3;

public class Member {
    private String cardNo;
    private String name;
    private String address;
    private String phone;
    private double unpaidDues;

    public Member(String cardNo, String name, String address, String phone, double unpaidDues) {
        this.cardNo = cardNo;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.unpaidDues = unpaidDues;
    }

    // Getters and setters
    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public double getUnpaidDues() {
        return unpaidDues;
    }

    public void setUnpaidDues(double unpaidDues) {
        this.unpaidDues = unpaidDues;
    }

    @Override
    public String toString() {
        return "Member{" +
                "cardNo='" + cardNo + '\'' +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", phone='" + phone + '\'' +
                ", unpaidDues=" + unpaidDues +
                '}';
    }
}

